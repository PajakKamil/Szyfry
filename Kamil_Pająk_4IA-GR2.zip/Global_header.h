#pragma once
#ifndef _global_header_h_

#include <iostream>
#include <vector>
#include <string>
#include <bitset>
#include <algorithm>
#include <time.h>
#include <cmath>

#define _global_header_h_

#endif // !1

